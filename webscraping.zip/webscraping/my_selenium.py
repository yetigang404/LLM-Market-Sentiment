from selenium import webdriver
from selenium.webdriver.common.by import By 
import csv
import subprocess


def web_scrape(driver, url, title_xpath, headline_xpath=None):
    driver.get(url)
    data = []
    
    if title_xpath:  # Check if title_xpath is provided and non-empty
        articles = driver.find_elements(By.XPATH, title_xpath)
        for article in articles:
            title = article.text
            if title:
                data.append([title])
    
    if headline_xpath:  # Check if headline_xpath is provided and non-empty
        headlines = driver.find_elements(By.XPATH, headline_xpath)
        for headline in headlines:
            headline_text = headline.text
            if headline_text:
                data.append([headline_text])
                
    return data

websites = [
    {
        "url": "https://finance.yahoo.com/news/",
        "title_xpath": '//h3/a'
    },
    {
        "url": "https://www.marketwatch.com/",
        "title_xpath": '//h3/a',
        "headline_xpath": '//div[@class="headline"]/h3/a'
    },
    {
        "url": "https://www.reuters.com/markets/",
        "title_xpath": '//a[contains(@class, "basic-card_title_3byrv")]'
    }
    
]
driver = webdriver.Chrome()

all_data = []
for site in websites:
    headline_xpath = site.get('headline_xpath')
    data = web_scrape(driver, site["url"], site["title_xpath"], headline_xpath)
    all_data.extend(data)


all_data = [line for line in all_data if "Watch Now" not in line]
    

with open('finance_articles.csv', 'w', newline='', encoding='utf-8') as file:
    writer = csv.writer(file)
    writer.writerow(['Title'])  # Writing headers
    writer.writerows(all_data)

driver.quit()  # Don't forget to quit the driver


csv_file_path = 'finance_articles.csv'

command = f"ollama run llama2 \"analyze the market sentiment of individual stocks based on the csv data: $({csv_file_path})\""
process = subprocess.run(command, shell=True, check=True, stdout=subprocess.PIPE, universal_newlines=True)
output = process.stdout

# Print the output of the command
print(output)
#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <vector>
#include <string>

int main() {
    std::string directory_path = "./market_articles";
    std::string output_file_path = "combined_output.txt";
    std::ofstream output_file(output_file_path);

    if (!output_file.is_open()) {
        std::cerr << "Failed to open output file." << std::endl;
        return 1;
    }

    for (int i = 1; i <= 30; ++i) {
        std::string txt_file_path = directory_path + "/" + std::to_string(i) + ".txt";
        std::ifstream input_file(txt_file_path);

        if (!input_file.is_open()) {
            output_file << "Failed to open " << txt_file_path << std::endl;
            continue;
        }

        std::stringstream buffer;
        buffer << input_file.rdbuf();
        std::string txt_content = buffer.str();

        std::string command = "ollama run llama2 \"pretend you are a financial expert. Given the following news headlines, tell me whether to go long or short on that trading day.: " + txt_content + "\"";
        int result = std::system(command.c_str());

        if (result != 0) {
            output_file << "Error executing command for " << txt_file_path << std::endl;
        }
    }

    std::cout << "Processing completed. Output written to: " << output_file_path << std::endl;
    return 0;
}

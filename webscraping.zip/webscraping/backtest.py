import subprocess
import glob

# Directory where your TXT files are stored
directory_path = '/market_articles'

# Output file path
output_file_path = 'combined_output.txt'

# Find all TXT files in the directory and sort them numerically
txt_files = sorted(glob.glob(f'{directory_path}/*.txt'), key=lambda x: int(x.split('/')[-1].split('.')[0]))

# Open the output file
with open(output_file_path, 'w') as output_file:
    # Process each TXT file in sorted order
    for txt_file_path in txt_files:
        try:
            # Read the content of the text file
            with open(txt_file_path, 'r') as file:
                txt_content = file.read()
            
            # Prepare the command
            command = f"ollama run llama2 \"pretend you are a financial expert. Given the following news headlines, tell me whether to go long or short on that trading day.: {txt_content}\""
            process = subprocess.run(command, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
            output = process.stdout

            # Write the output to the file
            output_file.write(f'Output for {txt_file_path}:\n{output}\n\n')
        except subprocess.CalledProcessError as e:
            output_file.write(f'Error processing {txt_file_path}:\n{e}\n\n')
        except Exception as e:
            output_file.write(f'Unhandled exception for {txt_file_path}:\n{e}\n\n')

# Inform that the process is completed
print("Processing completed. Output written to:", output_file_path)

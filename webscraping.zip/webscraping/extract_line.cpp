#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>

void processFile(const std::string &input_file_path) {
    std::string temp_file_path = input_file_path + ".temp";

    std::ifstream input_file(input_file_path);
    std::ofstream temp_file(temp_file_path);

    if (input_file.is_open() && temp_file.is_open()) {
        std::string line;

        while (getline(input_file, line)) {
            std::string start = line.substr(0, 5);
            std::transform(start.begin(), start.end(), start.begin(), ::tolower);

            if (start == "title") {
                temp_file << line << std::endl;
            }
        }

        input_file.close();
        temp_file.close();

        remove(input_file_path.c_str());
        rename(temp_file_path.c_str(), input_file_path.c_str());
    } else {
        std::cerr << "Unable to open " << input_file_path << std::endl;
    }
}

int main() {
    for (int i = 2; i <= 30; ++i) {
        std::string file_name = std::to_string(i) + ".txt";
        processFile(file_name);
    }

    return 0;
}
